Philip Linden 11/21/16
ENGL490 Advanced Creative Writing - Final Project

This project is a work of interactive fiction containing hypertext and mixed media. 

INSTALLATION
Extract all contents of LindenPhilip_cwfinalproject.zip to a single directory. Do not alter the file structure from its original state.

PLAYING THE GAME
Open Linden_cwfinalproject.html in your internet browser. Note: the game has only been tested using Google Chrome.

FEEDBACK
I look forward to hearing your thoughts on the piece so far. Here are some starter questions:
- Did you have a clear idea of what to do/how to progress the story?
- Were you frustrated by anything?
- How long did it take you to reach this page?
- How did the formatting affect your experience?
- Would music add more to the story or would you find it distracting?

Thanks!